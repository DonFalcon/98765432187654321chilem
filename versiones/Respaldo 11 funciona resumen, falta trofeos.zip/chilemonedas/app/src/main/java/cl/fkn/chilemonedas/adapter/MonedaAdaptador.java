package cl.fkn.chilemonedas.adapter;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import cl.fkn.chilemonedas.BD.ConstructorMonedas;
import cl.fkn.chilemonedas.BD.ConstructorTiposMonedas;
import cl.fkn.chilemonedas.BD.ConstructorUsuarioMoneda;
import cl.fkn.chilemonedas.pojo.Moneda;
import cl.fkn.chilemonedas.R;

import static cl.fkn.chilemonedas.R.id.parent;

/**
 * Created by DonFalcon on 16-07-2017.
 */

public class MonedaAdaptador extends RecyclerView.Adapter<MonedaAdaptador.MonedaViewHolder> {

    ArrayList<Moneda> monedas;
    Context context;

    public MonedaAdaptador(ArrayList<Moneda> monedas, Context context){

        this.monedas=monedas;
        // /PAra anoimar el recicler
        this.context = context;
    }

    @Override
    public MonedaAdaptador.MonedaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_moneda,parent,false);
        return new MonedaAdaptador.MonedaViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final MonedaAdaptador.MonedaViewHolder holder, int position) {

        final Moneda moneda = monedas.get(position);

        if (moneda.getVersion().equals("z")) {
            holder.tvAnoCardMoneda.setText(String.valueOf(moneda.getAno()));
        }else{
            holder.tvAnoCardMoneda.setText(String.valueOf(moneda.getAno()) +" ("+moneda.getVersion()+")");
        }

        holder.ivCardMoneda.setImageResource(moneda.getImagen());

        if(moneda.getColeccionada()){
            //holder.ivBackgroundCardMoneda.setImageResource(R.drawable.icons8_marca_de_verificaci_n_48);
            holder.tvAnoCardMoneda.setBackgroundColor(Color.rgb(139,195,74));
        }else{
            holder.tvAnoCardMoneda.setBackgroundColor(Color.WHITE);
        }

        //_============= Aqui se pone y elimina el ticket==========================================
        //========================================================================================

        //apretando el dibujo
        holder.ivCardMoneda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ConstructorMonedas constructorMonedas = new ConstructorMonedas(context);
                ConstructorTiposMonedas constructorTiposMonedas = new ConstructorTiposMonedas(context);
                ConstructorUsuarioMoneda constructorUsuarioMoneda = new ConstructorUsuarioMoneda(context);
                if(moneda.getColeccionada()){
                    holder.tvAnoCardMoneda.setBackgroundColor(Color.WHITE);
                    constructorMonedas.editarColeccionada(moneda);
                    constructorTiposMonedas.restarMonedaConteo(moneda);
                    constructorUsuarioMoneda.removerMoneda(moneda);
                    moneda.setColeccionada(false);
                }else {
                    //holder.ivBackgroundCardMoneda.setImageResource(R.drawable.icons8_marca_de_verificaci_n_48);
                    holder.tvAnoCardMoneda.setBackgroundColor(Color.rgb(0,191,165));
                    constructorMonedas.editarColeccionada(moneda);
                    constructorTiposMonedas.sumarMonedaConteo(moneda);
                    constructorUsuarioMoneda.insertarMoneda(moneda);
                    moneda.setColeccionada(true);
                }
            }
        });
        //=========================================================================================
        //setAnimation(holder.itemView, position);
    }

    @Override
    public int getItemCount() {
        return monedas.size();
    }

    public static class MonedaViewHolder extends RecyclerView.ViewHolder{

        private ImageView ivCardMoneda;
        private TextView tvAnoCardMoneda;
        private ImageView ivBackgroundCardMoneda;

        public MonedaViewHolder(View itemView) {
            super(itemView);

            ivCardMoneda = (ImageView) itemView.findViewById(R.id.ivCardMoneda);
            tvAnoCardMoneda = (TextView) itemView.findViewById(R.id.tvAnoCardMoneda);
            ivBackgroundCardMoneda = (ImageView) itemView.findViewById(R.id.ivBackgroundCardMoneda);

        }
    }

/* ================================ EN caso de querer animar el recicler view


 private int lastPosition = -1;
    private Context context;

    private void setAnimation(View viewToAnimate, int position)
    {
        // If the bound view wasn't previously displayed on screen, it's animated
        if (position > lastPosition)
        {
            Animation animation = AnimationUtils.loadAnimation(context, android.R.anim.slide_in_left);
            viewToAnimate.startAnimation(animation);
            lastPosition = position;
        }
    }

    */
}
