package cl.fkn.chilemonedas.pojo;

/**
 * Created by DonFalcon on 21-07-2017.
 */

public class Usuario {

    int id;
    String tipoColeccion;
    int totalColeccion;
    int cantidadColeccionada;
    int ultimaImagen1;
    int ultimaImagen2;
    int ultimaImagen3;
    int ultimaImagen4;
    int ultimaImagen5;
    int ultimaAno1;
    int ultimaAno2;
    int ultimaAno3;
    int ultimaAno4;
    int ultimaAno5;


    public Usuario() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipoColeccion() {
        return tipoColeccion;
    }

    public void setTipoColeccion(String tipoColeccion) {
        this.tipoColeccion = tipoColeccion;
    }

    public int getTotalColeccion() {
        return totalColeccion;
    }

    public void setTotalColeccion(int totalColeccion) {
        this.totalColeccion = totalColeccion;
    }

    public int getCantidadColeccionada() {
        return cantidadColeccionada;
    }

    public void setCantidadColeccionada(int cantidadColeccionada) {
        this.cantidadColeccionada = cantidadColeccionada;
    }

    public int getUltimaImagen1() {
        return ultimaImagen1;
    }

    public void setUltimaImagen1(int ultimaImagen1) {
        this.ultimaImagen1 = ultimaImagen1;
    }

    public int getUltimaImagen2() {
        return ultimaImagen2;
    }

    public void setUltimaImagen2(int ultimaImagen2) {
        this.ultimaImagen2 = ultimaImagen2;
    }

    public int getUltimaImagen3() {
        return ultimaImagen3;
    }

    public void setUltimaImagen3(int ultimaImagen3) {
        this.ultimaImagen3 = ultimaImagen3;
    }

    public int getUltimaImagen4() {
        return ultimaImagen4;
    }

    public void setUltimaImagen4(int ultimaImagen4) {
        this.ultimaImagen4 = ultimaImagen4;
    }

    public int getUltimaImagen5() {
        return ultimaImagen5;
    }

    public void setUltimaImagen5(int ultimaImagen5) {
        this.ultimaImagen5 = ultimaImagen5;
    }

    public int getUltimaAno1() {
        return ultimaAno1;
    }

    public void setUltimaAno1(int ultimaAno1) {
        this.ultimaAno1 = ultimaAno1;
    }

    public int getUltimaAno2() {
        return ultimaAno2;
    }

    public void setUltimaAno2(int ultimaAno2) {
        this.ultimaAno2 = ultimaAno2;
    }

    public int getUltimaAno3() {
        return ultimaAno3;
    }

    public void setUltimaAno3(int ultimaAno3) {
        this.ultimaAno3 = ultimaAno3;
    }

    public int getUltimaAno4() {
        return ultimaAno4;
    }

    public void setUltimaAno4(int ultimaAno4) {
        this.ultimaAno4 = ultimaAno4;
    }

    public int getUltimaAno5() {
        return ultimaAno5;
    }

    public void setUltimaAno5(int ultimaAno5) {
        this.ultimaAno5 = ultimaAno5;
    }






}
