package cl.fkn.chilemonedas.presentador;

/**
 * Created by DonFalcon on 18-07-2017.
 */

public interface IFragmentColeccionPresenter {

    public void obtenerTiposMonedasBD();
    public void mostrarTiposMonedasRV();


}
