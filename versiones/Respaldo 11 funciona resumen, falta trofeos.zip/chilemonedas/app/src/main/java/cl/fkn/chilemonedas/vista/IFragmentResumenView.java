package cl.fkn.chilemonedas.vista;

/**
 * Created by DonFalcon on 18-07-2017.
 */

public interface IFragmentResumenView {

    public void cargarCantidadMonedasColeccionadas();
    public void cargarUltimasMonedas();
    public void cargarTrofeos();

}
