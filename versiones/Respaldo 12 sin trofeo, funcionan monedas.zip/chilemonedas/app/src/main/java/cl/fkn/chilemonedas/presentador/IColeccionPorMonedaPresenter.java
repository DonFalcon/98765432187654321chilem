package cl.fkn.chilemonedas.presentador;

/**
 * Created by DonFalcon on 18-07-2017.
 */

public interface IColeccionPorMonedaPresenter {

    public void obtenerMonedasBD(int idTipoMoneda);
    public void mostrarMonedasRV();

}
